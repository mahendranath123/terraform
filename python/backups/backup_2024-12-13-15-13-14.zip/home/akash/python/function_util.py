import os
import datetime

# def time ():
#     return os.system('df -h')
# time()

# def paremeter(cmd):
#     return  os.system(cmd)
# paremeter('free -m')

def par():
    return  datetime.datetime.today()
print(par())