#!/bin/bash

echo "this is bash"

read -p "enter a name " name
echo " your $name  and  $datetime" 